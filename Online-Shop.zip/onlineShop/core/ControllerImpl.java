package onlineShop.core;

import onlineShop.core.interfaces.Controller;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.*;
import onlineShop.models.products.computers.Computer;
import onlineShop.models.products.computers.DesktopComputer;
import onlineShop.models.products.computers.Laptop;
import onlineShop.models.products.peripherals.*;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;

import static onlineShop.common.constants.ExceptionMessages.*;
import static onlineShop.common.constants.OutputMessages.*;

public class ControllerImpl implements Controller {
    List<Component> componentList;
    List<Peripheral> peripheralList;
    List<Computer> computerList;

    public ControllerImpl() {
        computerList = new ArrayList<>();
        componentList = new ArrayList<>();
        peripheralList = new ArrayList<>();
    }

    @Override
    public String addComputer(String computerType, int id, String manufacturer, String model, double price) {
        for (Computer computer : computerList) {
            if (computer.getId() == id) {
                throw new IllegalArgumentException(EXISTING_COMPUTER_ID);
            }
        }
        if (computerType.equals("Laptop")) {
            Computer comp = new Laptop(id, manufacturer, model, price);
            computerList.add(comp);
        } else if (computerType.equals("DesktopComputer")) {
            Computer comp = new DesktopComputer(id, manufacturer, model, price);
            computerList.add(comp);
        } else {
            throw new IllegalArgumentException(INVALID_COMPUTER_TYPE);
        }
        return String.format(ADDED_COMPUTER, id);
    }

    @Override
    public String addPeripheral(int computerId, int id, String peripheralType, String manufacturer, String model, double price, double overallPerformance, String connectionType) {
        Check(computerId);
        Peripheral peripheral = null;
        if (peripheralType.equals("Headset")) {
            peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
        } else if (peripheralType.equals("Keyboard")) {
            peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
        } else if (peripheralType.equals("Monitor")) {
            peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
        } else if (peripheralType.equals("Mouse")) {
            peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
        } else {
            throw new IllegalArgumentException(INVALID_PERIPHERAL_TYPE);
        }

        for (Peripheral peripheral1 : peripheralList) {
            if (peripheral1.getId() == id) {
                throw new IllegalArgumentException(EXISTING_PERIPHERAL_ID);
            }
        }
        for (Computer computer : computerList) {
            if (computer.getId() == computerId) {
                computer.getPeripherals().add(peripheral);
                peripheralList.add(peripheral);
                return String.format(ADDED_PERIPHERAL, peripheralType, id, computerId);
            }
        }
        return "neshto se obyrka";

    }

    @Override
    public String removePeripheral(String peripheralType, int computerId) {
        Check(computerId);
        Peripheral peripheral = peripheralList.stream().filter(e -> e.getClass().getSimpleName().equals(peripheralType)).findFirst().orElse(null);
        if (peripheral != null) {
            for (Computer computer : computerList) {
                if (computer.getId() == computerId) {
                    computer.getPeripherals().remove(peripheral);
                    peripheralList.remove(peripheral);
                    return String.format(REMOVED_PERIPHERAL, peripheralType, peripheral.getId());
                }
            }
        }
        return "";
    }

    @Override
    public String addComponent(int computerId, int id, String componentType, String manufacturer, String model, double price, double overallPerformance, int generation) {
        Check(computerId);
        Component component = null;
        if (componentType.equals("CentralProcessingUnit")) {
            component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
        } else if (componentType.equals("Motherboard")) {
            component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
        } else if (componentType.equals("PowerSupply")) {
            component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
        } else if (componentType.equals("RandomAccessMemory")) {
            component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
        } else if (componentType.equals("SolidStateDrive")) {
            component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
        } else if (componentType.equals("VideoCard")) {
            component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
        } else {
            throw new IllegalArgumentException(INVALID_COMPONENT_TYPE);
        }

        for (Component component1 : componentList) {
            if (component1.getId() == id) {
                throw new IllegalArgumentException(EXISTING_COMPONENT_ID);
            }
        }
        for (Computer computer : computerList) {
            if (computer.getId() == computerId) {
                computer.getComponents().add(component);
                componentList.add(component);
                return String.format(ADDED_COMPONENT, componentType, id, computerId);
            }
        }
        return "neshto se obyrka";
    }

    @Override
    public String removeComponent(String componentType, int computerId) {
        Check(computerId);
        Component component = componentList.stream().filter(e -> e.getClass().getSimpleName().equals(componentType)).findFirst().orElse(null);
        if (component != null) {
            for (Computer computer : computerList) {
                if (computer.getId() == computerId) {
                    computer.getComponents().remove(component);
                    componentList.remove(component);
                    return String.format(REMOVED_COMPONENT, componentType, component.getId());
                }
            }
        } else {
            Computer comp = computerList.stream().filter(e -> e.getId() == computerId).findFirst().orElse(null);
            return String.format(NOT_EXISTING_COMPONENT, componentType, comp.getClass().getSimpleName(), computerId);
        }
        return "e sq ako ne stane sa hvyrlqi";
    }

    @Override
    public String buyComputer(int id) {
        Check(id);
        Computer comp = computerList.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
        if (comp != null) {
            computerList.remove(comp);
            return comp.toString();
        }
        return "";
    }

    @Override
    public String BuyBestComputer(double budget) {
        double initPerformance = 0;
        Computer comp = null;
        double price = computerList.stream().mapToDouble(i -> i.getPrice()).min().getAsDouble();
        if (budget < price || computerList.isEmpty()) {
            throw new IllegalArgumentException(String.format(CAN_NOT_BUY_COMPUTER, budget));
        } else {
            for (Computer computer : computerList) {
                if (computer.getPrice() <= budget && computer.getOverallPerformance() > initPerformance) {
                    initPerformance = computer.getOverallPerformance();
                    comp = computer;
                }
            }
        }
        return comp.toString();
    }

    @Override
    public String getComputerData(int id) {
        Check(id);
        for (Computer computer : computerList) {
            if (computer.getId() == id) {
                return computer.toString();
            }
        }
        return null;
    }

    public void Check(int id) {
        boolean exists = false;
        for (Computer computer : computerList) {
            if (computer.getId() == id) {
                exists = true;
            }
        }
        if (!exists) {
            throw new IllegalArgumentException(NOT_EXISTING_COMPUTER_ID);
        }
    }
}
