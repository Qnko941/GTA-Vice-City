package onlineShop.models.products.components;

import onlineShop.models.products.BaseProduct;

import static onlineShop.common.constants.OutputMessages.COMPONENT_TO_STRING;

public abstract class BaseComponent extends BaseProduct implements Component{
    public static final double CentralProcessingUnit_multiplier = 1.25;
    public static final double Motherboard_multiplier = 1.25;
    public static final double PowerSupply_multiplier = 1.05;
    public static final double RandomAccessMemory_multiplier = 1.20;
    public static final double SolidStateDrive_multiplier = 1.20;
    public static final double VideoCard_multiplier = 1.15;
    private int generation;

    protected BaseComponent(int id, String manufacturer, String model, double price, double overallPerformance, int generation) {
        super(id, manufacturer, model, price, overallPerformance);
        this.generation = generation;
    }

    @Override
    public int getGeneration() {
        return 0;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(COMPONENT_TO_STRING, this.generation);
    }
}
