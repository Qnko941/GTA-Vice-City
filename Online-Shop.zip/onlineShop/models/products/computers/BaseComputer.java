package onlineShop.models.products.computers;

import onlineShop.models.products.BaseProduct;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.CentralProcessingUnit;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.*;

import static onlineShop.common.constants.ExceptionMessages.EXISTING_COMPONENT;
import static onlineShop.common.constants.ExceptionMessages.*;
import static onlineShop.common.constants.OutputMessages.*;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<Component> componentList;
    private List<Peripheral> peripheralList;

    protected BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        componentList = new ArrayList<>();
        peripheralList = new ArrayList<>();
    }

    @Override
    public List<Component> getComponents() {
        return this.componentList;
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return this.peripheralList;
    }

    @Override
    public void addComponent(Component component) {
        for (Component component1 : componentList) {
            if (component1.getClass().getSimpleName().equals(component.getClass().getSimpleName())) {
                throw new IllegalArgumentException(String.format(EXISTING_COMPONENT, component.getClass().getSimpleName(), this.getClass().getSimpleName(), getId()));
            }
        }
        componentList.add(component);
    }

    @Override
    public Component removeComponent(String componentType) {
        Component component = null;
        if (componentList.isEmpty() || componentList.stream().noneMatch(e -> e.getClass().getSimpleName().equals(componentType))) {
            throw new IllegalArgumentException(String.format(NOT_EXISTING_COMPONENT, componentType, this.getClass().getSimpleName(), getId()));
        }
        component = componentList.stream().filter(e -> e.getClass().getSimpleName().equals(componentType)).findFirst().orElse(null);
        componentList.remove(component);
        return component;
    }


    @Override
    public void addPeripheral(Peripheral peripheral) {
        for (Peripheral peripheral1 : peripheralList) {
            if (peripheral.getClass().getSimpleName().equals(peripheral.getClass().getSimpleName())) {
                throw new IllegalArgumentException(String.format(EXISTING_PERIPHERAL, peripheral.getClass().getSimpleName(), this.getClass().getSimpleName(), getId()));
            }
        }
        this.peripheralList.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {
        Peripheral peripheral = null;
        if (peripheralList.isEmpty() || peripheralList.stream().noneMatch(e -> e.getClass().getSimpleName().equals(peripheralType))) {
            throw new IllegalArgumentException(String.format(NOT_EXISTING_PERIPHERAL, peripheralType, this.getClass().getSimpleName(), getId()));
        }
        peripheral = peripheralList.stream().filter(e -> e.getClass().getSimpleName().equals(peripheralType)).findFirst().orElse(null);
        componentList.remove(peripheral);
        return peripheral;
    }

    @Override
    public double getOverallPerformance() {
        if (componentList.isEmpty()) {
            return super.getOverallPerformance();
        } else {
            return  componentList.stream().mapToDouble(Product::getOverallPerformance).average().getAsDouble() + super.getOverallPerformance();
        }
    }

    @Override
    public double getPrice() {
        double totalPrice = super.getPrice();
        for (Component component : componentList) {
            totalPrice += component.getPrice();
        }
        for (Peripheral peripheral : peripheralList) {
            totalPrice += peripheral.getPrice();
        }
        return totalPrice;
    }

    @Override
    public String toString() {

        OptionalDouble averagePerformance = peripheralList.stream().mapToDouble(Product::getOverallPerformance).average();
        StringBuilder sb = new StringBuilder();
       sb.append(String.format(PRODUCT_TO_STRING, getOverallPerformance(), getPrice(), this.getClass().getSimpleName(), getManufacturer(), getModel(), getId()));
        sb.append(System.lineSeparator());
        sb.append(String.format(" " + COMPUTER_COMPONENTS_TO_STRING, componentList.size()));
        sb.append(System.lineSeparator());
        for (Component component : componentList) {
            sb.append("  " + component).append(System.lineSeparator());
        }
        if (!peripheralList.isEmpty()) {
            sb.append(String.format(" " +COMPUTER_PERIPHERALS_TO_STRING, peripheralList.size(), averagePerformance.getAsDouble())).append(System.lineSeparator()).append("  ");
        } else {
            sb.append(String.format(" " +COMPUTER_PERIPHERALS_TO_STRING, 0, 0.00));
        }

        for (Peripheral peripheral : peripheralList) {
            sb.append(peripheral);
        }
        return sb.toString();
    }
}
